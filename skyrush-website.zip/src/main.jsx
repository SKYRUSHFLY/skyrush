import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Rocket, Zap, ShieldCheck, TrendingUp, Users, Trophy, Coins, ArrowRight, Gamepad2 } from "lucide-react";
import "./styles.css";

function useDemoAuth() {
  const [user, setUser] = useState(() => localStorage.getItem("skyrush_user") || "");
  const login = () => { localStorage.setItem("skyrush_user", "Demo Pilot"); setUser("Demo Pilot"); };
  const logout = () => { localStorage.removeItem("skyrush_user"); setUser(""); };
  return { user, login, logout };
}

function Navbar({ user, login, logout }) {
  return <header className="nav">
    <div className="wrap nav-inner">
      <Link to="/" className="brand"><span className="brand-icon"><Rocket size={19}/></span> SKY<span>RUSH</span></Link>
      <div className="nav-actions">
        {user ? <>
          <span className="demo-user">{user}</span>
          <Link className="btn small" to="/play">Play</Link>
          <button className="btn ghost small" onClick={logout}>Log out</button>
        </> : <>
          <button className="btn ghost small" onClick={login}>Log in</button>
          <button className="btn small" onClick={login}>Sign up</button>
        </>}
      </div>
    </div>
  </header>;
}

const features = [
  [Zap, "Instant Rounds", "Fast demo rounds with a rising multiplier and manual cash-out."],
  [ShieldCheck, "Provably Fair Design", "The production version can use independently verifiable server/client seeds."],
  [TrendingUp, "Auto Cashout", "Demo target controls can be added before connecting a real backend."],
  [Users, "Live Multiplayer", "Designed for a real-time lobby experience."],
  [Trophy, "Leaderboards", "Track demo performance and rankings."],
  [Coins, "1000 Free Coins", "Play-money only — no deposits or cash prizes in this starter."],
];

function Landing({ user, login }) {
  const navigate = useNavigate();
  return <div>
    <Navbar user={user} login={login} logout={()=>{}} />
    <section className="hero">
      <div className="glow one"/><div className="glow two"/>
      <div className="wrap hero-grid">
        <div>
          <div className="pill"><i/> LIVE PLAY-MONEY CRASH GAME</div>
          <motion.h1 initial={{opacity:0,y:20}} animate={{opacity:1,y:0}}>How high<br/>will you <b>fly?</b></motion.h1>
          <p>Experience an Aviator-style crash-game interface using free play-money. Watch the multiplier rise and cash out before the demo round crashes.</p>
          <div className="cta-row">
            <button className="btn large" onClick={()=>{ if(!user) login(); navigate("/play"); }}><Gamepad2 size={20}/> Play Free <ArrowRight size={20}/></button>
            <span>No download · No real money</span>
          </div>
        </div>
        <div className="preview card">
          <div className="label">CURRENT ROUND</div>
          <motion.div className="mult" animate={{scale:[1,1.05,1]}} transition={{duration:2,repeat:Infinity}}>4.28x</motion.div>
          <div className="chips">{[1.24,8.91,2.07,1.02].map(v=><span className={v>3?"green":v>1.5?"yellow":"red"} key={v}>{v.toFixed(2)}x</span>)}</div>
          <motion.div className="rocket" animate={{rotate:[-8,4,-8],y:[0,-8,0]}} transition={{duration:3,repeat:Infinity}}><Rocket size={42}/></motion.div>
        </div>
      </div>
    </section>
    <section className="stats"><div className="wrap stats-grid">
      {[[ "12k+","Demo rounds"],["100%","Play-money"],["1000","Free coins"],["24/7","Demo lobby"]].map(x=><div key={x[1]}><strong>{x[0]}</strong><small>{x[1]}</small></div>)}
    </div></section>
    <section className="wrap section">
      <h2>How it works</h2><p className="center">Three simple steps.</p>
      <div className="three">{[["01","Place your bet","Choose a play-money amount."],["02","Watch it climb","The demo multiplier rises."],["03","Cash out in time","Cash out before the demo crash."]].map(x=><div className="card step" key={x[0]}><em>{x[0]}</em><h3>{x[1]}</h3><p>{x[2]}</p></div>)}</div>
    </section>
    <section className="section dark"><div className="wrap"><h2>Built for the rush</h2><p className="center">A clean starter foundation for your website.</p><div className="features">{features.map(([I,t,d])=><div className="card feature" key={t}><span><I/></span><h3>{t}</h3><p>{d}</p></div>)}</div></div></section>
    <footer>SKYRUSH · Play-money entertainment demo · No real-money deposits or cash prizes</footer>
  </div>;
}

function Game({ user, login, logout }) {
  const [mult, setMult] = useState(1);
  const [phase, setPhase] = useState("running");
  const [bet, setBet] = useState(100);
  const [message, setMessage] = useState("Round running — cash out before the demo crash.");
  const [history, setHistory] = useState([1.24, 2.18, 8.91, 1.07, 3.62]);
  useEffect(() => {
    if (!user) login();
    let crash = 1.5 + Math.random()*8.5;
    let timer;
    const tick = () => {
      setMult(m => {
        const next = +(m * 1.018).toFixed(2);
        if (next >= crash) { setPhase("crashed"); setMessage(`Demo crash at ${crash.toFixed(2)}x`); clearInterval(timer); setHistory(h=>[+crash.toFixed(2),...h].slice(0,10)); return +crash.toFixed(2); }
        return next;
      });
    };
    timer = setInterval(tick, 100);
    return () => clearInterval(timer);
  }, [user, history.length]);

  const restart = () => { setMult(1); setPhase("running"); setMessage("New demo round started."); };
  const cashout = () => { if (phase==="running") { setPhase("cashed"); setMessage(`Demo cash-out at ${mult.toFixed(2)}x`); } };

  return <div><Navbar user={user} login={login} logout={logout}/><main className="wrap game">
    <div className="card gamebox">
      <div className="history">{history.map((v,i)=><span key={i} className={v>3?"green":v>1.5?"yellow":"red"}>{v.toFixed(2)}x</span>)}</div>
      <div className="game-screen">
        <div className="screen-label">{phase==="crashed"?"CRASHED":phase==="cashed"?"CASHED OUT":"LIVE DEMO ROUND"}</div>
        <div className={"big-mult "+(phase==="crashed"?"crashed":"")}>{mult.toFixed(2)}x</div>
        <Rocket className="big-rocket" size={64}/>
      </div>
      <div className="panel">
        <label>Play-money bet <input type="number" min="1" value={bet} onChange={e=>setBet(Math.max(1,+e.target.value||1))}/></label>
        {phase==="running" ? <button className="btn large cash" onClick={cashout}>Cash out {mult.toFixed(2)}x</button> : <button className="btn large" onClick={restart}>Start new demo round</button>}
      </div>
      <p className="status"><ShieldCheck size={16}/> {message}</p>
    </div>
  </main></div>;
}

function App() {
  const auth = useDemoAuth();
  const path = window.location.pathname;
  return path === "/play" ? <Game {...auth}/> : <Landing {...auth}/>;
}

createRoot(document.getElementById("root")).render(<BrowserRouter><App/></BrowserRouter>);